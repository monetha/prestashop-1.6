<?php

namespace Monetha\Consts;

class Resource
{
    const ORDER = 'order';
}
